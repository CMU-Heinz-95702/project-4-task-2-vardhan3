//Vardhan Khara
//vkhara

package org.example;

import java.io.IOException;
import java.net.*;
import java.util.Scanner;
import com.google.gson.Gson;

public class NeuralNetworkClient {

    private static final int serverPort = 4321;
    private static final String serverAdd = "localhost";
    private static DatagramSocket cSocket;
    private static InetAddress serverIPAddress;
    private static final Gson gson = new Gson();

    public static void main(String[] args) throws IOException {
        cSocket = new DatagramSocket();
        serverIPAddress = InetAddress.getByName(serverAdd);

        try (Scanner scanner = new Scanner(System.in)) {
            while (true) {
                int userInput= maintask(scanner);

                if (userInput == 5) {
                    System.out.println("Exiting program.");
                    break;
                }

                selectOption(userInput, scanner);
            }
        } finally {
            cSocket.close();
        }
    }
    private static void selectOption(int userInput, Scanner scanner) throws IOException {
        switch (userInput) {
            case 0:
                C1("{\"request\":\"getCurrentRange\"}");
                break;

            case 1:
                System.out.println("Input four binary outcomes corresponding to a 4x2 logic table. Each entry must be either 0 or 1.");
                double p = scanner.nextDouble();
                double q = scanner.nextDouble();
                double r = scanner.nextDouble();
                double s = scanner.nextDouble();
                String req1 = String.format("{\"request\":\"setCurrentRange\", \"val1\":%f, \"val2\":%f, \"val3\":%f, \"val4\":%f}", p, q, r, s);
                C1(req1);
                break;

            case 2:
                C1("{\"request\":\"train\", \"iterations\":1}");
                break;

            case 3:
                System.out.println("Specify the number of iterations for training.");
                int n = scanner.nextInt();
                String req3 = String.format("{\"request\":\"train\", \"iterations\":%d}", n);
                C1(req3);
                break;

            case 4:
                System.out.println("Provide a pair of inputs from a single row of the logic table. These represent the input values.");
                double value1 = scanner.nextDouble();
                double value2 = scanner.nextDouble();
                String req4 = String.format("{\"request\":\"test\", \"val1\":%f, \"val2\":%f}", value1, value2);
                C1(req4);
                break;
            case 5:
                System.out.println("Terminating the application.");
                System.exit(0);
                break;

            default:
                System.out.println("Option not recognized. Please select another.");
                break;
        }
    }

    private static void C1(String jsonReq) throws IOException {
        // Concatenate the request string with the response for a singular output
        String output = "Request sent to server: " + jsonReq;

        byte[] sendData = jsonReq.getBytes();
        DatagramPacket sendMessage = new DatagramPacket(sendData, sendData.length, serverIPAddress, serverPort);
        cSocket.send(sendMessage);

        byte[] getData = new byte[1024];
        DatagramPacket getPacket = new DatagramPacket(getData, getData.length);
        cSocket.receive(getPacket);
        String jsonRes = new String(getPacket.getData(), 0, getPacket.getLength());

        output += "\nResponse from server: " + jsonRes;

        System.out.println(output);
    }




    private static int maintask(Scanner scanner) {
        System.out.println("\nMain Menu");
        System.out.println("0. Display the current truth table.");
        System.out.println("1. Set the range values for the truth table.");
        System.out.println("2. Perform a single training step.");
        System.out.println("3. Perform multiple training steps.");
        System.out.println("4. Test with a pair of inputs.");
        System.out.println("5. Exit program.");
        System.out.print("Select an option: ");
        return scanner.nextInt();
    }
}