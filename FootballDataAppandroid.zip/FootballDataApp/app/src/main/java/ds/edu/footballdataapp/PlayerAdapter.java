//package ds.edu.footballdataapp;
//
//
//
//import android.app.Activity;
//import android.content.Context;
//import android.util.Log;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.ArrayAdapter;
//import android.widget.Filter;
//import android.widget.TextView;
//
//import java.util.ArrayList;
//import java.util.List;
//
//public class PlayerAdapter extends ArrayAdapter<Player> {
//
//
//    private List<Player> players;
//    private List<Player> filteredPlayers;
//    private Filter playerFilter;
//
//    public PlayerAdapter(Context context, List<Player> players) {
//        super(context, 0, players);
//        this.players = players;
//        this.filteredPlayers = new ArrayList<>(players);
//        // Initialize your filter here
//        playerFilter = new Filter() {
//            @Override
//            protected FilterResults performFiltering(CharSequence constraint) {
//                FilterResults results = new FilterResults();
//                if (constraint == null || constraint.length() == 0) {
//                    results.values = players;
//                    results.count = players.size();
//                } else {
//                    String searchStr = constraint.toString().toLowerCase();
//                    List<Player> resultData = new ArrayList<>();
//                    for (Player player : players) {
//                        if (player.getPlayer().toLowerCase().contains(searchStr)) {
//                            resultData.add(player);
//                        }
//                    }
//                    results.values = resultData;
//                    results.count = resultData.size();
//                }
//                return results;
//            }
//
//            @Override
//            protected void publishResults(CharSequence constraint, FilterResults results) {
//                filteredPlayers = (List<Player>) results.values;
//                notifyDataSetChanged();
//            }
//        };
//    }
//
//    @Override
//    public int getCount() {
//        return filteredPlayers.size();
//    }
//
//    @Override
//    public Player getItem(int position) {
//        return filteredPlayers.get(position);
//    }
//
//    @Override
//    public Filter getFilter() {
//        return playerFilter;
//    }

// ... existing getView method ...

//    List<Player> players;
//    public PlayerAdapter(Context context, List<Player> players) {
//        super(context, 0, players);
//        this.players=players;
//
//    }
//
//    @Override
//    public View getView(int position, View convertView, ViewGroup parent) {
//        Player player = this.players.get(position);
//        System.out.println(player.getPlayer()+" "+player.getGoals());
//        Log.e("errrror",player.getPlayer()+" "+player.getGoals());
//        if (convertView == null) {
//            convertView = LayoutInflater.from(getContext()).inflate(R.layout.player_item, parent, false);
//        }
//        TextView playerName = convertView.findViewById(R.id.playerName);
//        TextView playerGoals = convertView.findViewById(R.id.playerGoals);
//
//        playerName.setText(player.getPlayer());
//        playerGoals.setText(String.valueOf(player.getGoals()));
//
//        return convertView;
//    }
//}

package ds.edu.footballdataapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class PlayerAdapter extends ArrayAdapter<Player> {
    private List<Player> players;

    // Constructor
    public PlayerAdapter(Context context, List<Player> players) {
        super(context, 0, players);
        this.players = players;
    }

    // Creates new views (invoked by the layout manager)
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // Get the data item for this position
        Player player = getItem(position);

        // Check if an existing view is being reused, otherwise inflate the view
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.player_item, parent, false);
        }

        // Lookup view for data population
        TextView playerName = convertView.findViewById(R.id.playerName);
        TextView playerGoals = convertView.findViewById(R.id.playerGoals);

        // Populate the data into the template view using the data object
        playerName.setText(player.getPlayer());
        playerGoals.setText(String.valueOf(player.getGoals()));

        // Return the completed view to render on screen
        return convertView;
    }

    // Method to update the list of players within the adapter
    public void updatePlayers(List<Player> newPlayers) {
        players.clear();
        players.addAll(newPlayers);
        notifyDataSetChanged();
    }
}

