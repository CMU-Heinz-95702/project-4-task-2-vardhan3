//package ds.edu.footballdataapp;
//
//import android.os.Bundle;
//import android.view.View;
//import android.widget.Button;
//import android.widget.EditText;
//import android.widget.TextView;
//
//import androidx.activity.EdgeToEdge;
//import androidx.appcompat.app.AppCompatActivity;
//import androidx.core.graphics.Insets;
//import androidx.core.view.ViewCompat;
//import androidx.core.view.WindowInsetsCompat;
//
//public class MainActivity extends AppCompatActivity {
//
//    private EditText inputEditText;
//    private Button submitButton;
//    private TextView resultTextView;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_main);
//
//        inputEditText = findViewById(R.id.inputEditText);
//        submitButton = findViewById(R.id.submitButton);
//        resultTextView = findViewById(R.id.resultTextView);
//
//        submitButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                String userInput = inputEditText.getText().toString();
//                // Validate input and perform the web service request
//                // Update resultTextView with the result
//            }
//        });
//    }
//}




package ds.edu.footballdataapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;
import java.util.concurrent.Executors;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {

    private EditText inputEditText;
    private Button submitButton;
    private TextView resultTextView;
    private OkHttpClient client = new OkHttpClient();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Intent intent = new Intent(MainActivity.this,Teams.class);
        startActivity(intent);


    }

    private void fetchWebServiceData(String userInput) {
        // Replace with your web service URL and add user input to the query if needed
        String url = "https://organic-fishstick-j7995g9599r3qpxg-8080.app.github.dev/data/scorers" + userInput;

        // Use Executors to run the network request on a background thread
        Executors.newSingleThreadExecutor().execute(() -> {
            Request request = new Request.Builder()
                    .url(url)
                    .build();

            try (Response response = client.newCall(request).execute()) {
                // Make sure to check if the response is successful
                if (response.isSuccessful() && response.body() != null) {
                    String responseData = response.body().string();
                    // Update the UI on the main thread
                    runOnUiThread(() -> resultTextView.setText(responseData));
                } else {
                    // Update the UI on the main thread in case of an error
                    runOnUiThread(() -> resultTextView.setText("Failed to fetch data"));
                }
            } catch (IOException e) {
                e.printStackTrace();
                // Update the UI on the main thread in case of an exception
                runOnUiThread(() -> resultTextView.setText("Error occurred"));
            }
        });
    }
}
