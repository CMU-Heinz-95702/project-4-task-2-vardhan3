//package ds.edu.footballdataapp;
//
//import android.os.Bundle;
//import android.util.Log;
//import android.widget.EditText;
//import android.widget.ListView;
//import android.text.TextWatcher;
//import android.text.Editable;
//
//import androidx.appcompat.app.AppCompatActivity;
//
//import com.google.gson.Gson;
//import com.google.gson.reflect.TypeToken;
//
//import java.io.IOException;
//import java.lang.reflect.Type;
//import java.util.ArrayList;
//import java.util.List;
//import java.util.concurrent.Executors;
//import java.util.stream.Collectors;
//
//import okhttp3.OkHttpClient;
//import okhttp3.Request;
//import okhttp3.Response;
//
//public class Teams extends AppCompatActivity {
//
//    private List<Player> playerList = new ArrayList<>();
//    private List<Player> filteredPlayerList = new ArrayList<>();
//    private PlayerAdapter adapter;
//    private OkHttpClient client = new OkHttpClient();
//
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_teams);
//
//        // Initialize views
//        EditText searchEditText = findViewById(R.id.searchEditText);
//        ListView listView = findViewById(R.id.playerListView);
//
//        // Initialize player list with JSON data
//        String jsonData = "[{\"Player\":\"Mohamed Salah\",\"Goals\":23},{\"Player\":\"Son Heungmin\",\"Goals\":23}]";
//        Gson gson = new Gson();
//        Type type = new TypeToken<List<Player>>() {}.getType();
//        playerList = gson.fromJson(jsonData, type);
//        filteredPlayerList = new ArrayList<>(playerList); // Initialize filtered list
//
//        // Set up adapter and list view
//        adapter = new PlayerAdapter(this, filteredPlayerList);
//        listView.setAdapter(adapter);
//
//        // Set up search functionality
//        searchEditText.addTextChangedListener(new TextWatcher() {
//            @Override
//            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}
//
//            @Override
//            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
//                filter(charSequence.toString());
//            }
//
//            @Override
//            public void afterTextChanged(Editable editable) {}
//        });
//
//
//        fetchPlayersData();
//    }
//
//
//    private void fetchPlayersData() {
//        String url = "http://192.168.0.33:8080/Project4Task2-1.0-SNAPSHOT/data/scorers";
//
//        // Asynchronous operation to fetch data
//        Executors.newSingleThreadExecutor().execute(() -> {
//            Log.d("PlayersData", "Attempting to fetch data...");
//            Request request = new Request.Builder().url(url).build();
//
//            try (Response response = client.newCall(request).execute()) {
//                // Rest of your code...
//
//                Log.d("PlayersData", "Data fetched successfully");
//            } catch (IOException e) {
//                Log.e("PlayersData", "IOException: " + e.getMessage(), e);
//                // Rest of your code...
//            } catch (Exception e) {
//                Log.e("PlayersData", "Exception: " + e.getMessage(), e);
//                // Rest of your code...
//            }
//        });
//    }
//
//
//    private void updatePlayerList(String jsonData) {
//        Gson gson = new Gson();
//        Type type = new TypeToken<List<Player>>() {}.getType();
//        playerList = gson.fromJson(jsonData, type);
//        filteredPlayerList = new ArrayList<>(playerList); // Initialize filtered list
//
//        // Set up adapter with the fetched data
//        if (adapter == null) {
//            adapter = new PlayerAdapter(this, filteredPlayerList);
//            ListView listView = findViewById(R.id.playerListView);
//            listView.setAdapter(adapter);
//        } else {
//            adapter.updatePlayers(filteredPlayerList);
//        }
//    }
//
//    private void filter(String text) {
//        if (text.isEmpty()) {
//            filteredPlayerList = new ArrayList<>(playerList); // No filter
//        } else {
//            filteredPlayerList = playerList.stream()
//                    .filter(player -> player.getPlayer().toLowerCase().contains(text.toLowerCase()))
//                    .collect(Collectors.toList()); // Filtered list
//        }
//        adapter.updatePlayers(filteredPlayerList); // Update adapter with filtered results
//    }
//}


package ds.edu.footballdataapp;

import android.os.Bundle;
import android.util.Log;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import android.text.TextWatcher;
import android.text.Editable;

import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class Teams extends AppCompatActivity {

    private List<Player> playerList = new ArrayList<>();
    private PlayerAdapter adapter;
    private OkHttpClient client = new OkHttpClient();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teams);

        EditText searchEditText = findViewById(R.id.searchEditText);
        ListView listView = findViewById(R.id.playerListView);

        adapter = new PlayerAdapter(this, new ArrayList<>());
        listView.setAdapter(adapter);

        fetchPlayersData();

        searchEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                filter(charSequence.toString());
            }

            @Override
            public void afterTextChanged(Editable editable) {}
        });
    }

//    private void fetchPlayersData() {
//        String url = "https://organic-fishstick-j7995g9599r3qpxg-8080.app.github.dev/data/scorers";
//        Log.e("URL",url);
//        Executors.newSingleThreadExecutor().execute(() -> {
//            Log.d("Teams", "Attempting to fetch data...");
//            Request request = new Request.Builder().url(url).build();
//
//            try (Response response = client.newCall(request).execute()) {
//                if (response.isSuccessful() && response.body() != null) {
//                    String responseData = response.body().string();
//                    Log.d("Teams", "Data fetched successfully");
//                    updatePlayerList(responseData);
//                } else {
//                    Log.e("Teams", "Server responded with an error");
//                    showToast("Failed to fetch data");
//                }
//            } catch (IOException e) {
//                Log.e("Teams", "IOException occurred: " + e.getMessage(), e);
//                showToast("Error occurred");
//            } catch (Exception e) {
//                Log.e("Teams", "Unexpected exception occurred: " + e.getMessage(), e);
//                showToast("Unexpected error occurred");
//            }
//        });
//    }

    private void fetchPlayersData() {

        String url = "https://zany-train-q466qx6q96q3xpj6-8080.app.github.dev/data/scorers";
        Log.e("LOLLOL",url);
        Executors.newSingleThreadExecutor().execute(() -> {
            HttpURLConnection urlConnection = null;
            try {
                URL requestURL = new URL(url);
                urlConnection = (HttpURLConnection) requestURL.openConnection();
                urlConnection.setRequestMethod("GET");

                int responseCode = urlConnection.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    InputStream inputStream = urlConnection.getInputStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }

                    Log.d("Teams", "Data fetched successfully");
                    updatePlayerList(response.toString());
                } else {
                    Log.e("Teams", "Server responded with an error");
                    showToast("Failed to fetch data");
                }
            } catch (IOException e) {
                Log.e("Teams", "IOException occurred: " + e.getMessage(), e);
                showToast("Error occurred");
            } finally {
                if (urlConnection != null) {
                    urlConnection.disconnect();
                }
            }
        });
    }


    private void showToast(final String text) {
        runOnUiThread(() -> Toast.makeText(Teams.this, text, Toast.LENGTH_SHORT).show());
    }

    private void updatePlayerList(String jsonData) {
        Gson gson = new Gson();
        Type type = new TypeToken<List<Player>>() {}.getType();
        playerList = gson.fromJson(jsonData, type);
        runOnUiThread(() -> adapter.updatePlayers(playerList));
    }

    private void filter(String text) {
        List<Player> filteredList = new ArrayList<>();
        if (text.isEmpty()) {
            filteredList = playerList;
        } else {
            for (Player player : playerList) {
                if (player.getPlayer().toLowerCase().contains(text.toLowerCase())) {
                    filteredList.add(player);
                }
            }
        }
        adapter.updatePlayers(filteredList);
    }
}
