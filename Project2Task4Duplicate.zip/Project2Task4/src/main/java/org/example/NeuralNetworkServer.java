//Vardhan Khara
//Andrew ID: vkhara

/*
 * Overview: This module encapsulates the server-side functionality for a neural network-based application,
 * operating over UDP for receiving and processing requests such as fetching current neural network parameters,
 * updating training datasets, initiating neural network training, and conducting tests with specified inputs.
 */


package org.example;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.net.SocketException;
import java.util.*;

public class NeuralNetworkServer {

    // Server configuration and neural network initialization

    public static final int portNumber = 4321;
    public DatagramSocket sNum;
    public Gson gson;

    public NeuralNetwork neuralNetwork;
    public  ArrayList<Double[][]> UTS;

    // Starting of the program
    public static void main(String[] args) {
        try {
            new NeuralNetworkServer().Programbegin();
        } catch (SocketException e) {
            e.printStackTrace();
        }
    }
    public NeuralNetworkServer() throws SocketException {
        /* Server Initiation:
         * Establishes the server socket and preloads the neural network with default training sets.
         */
        sNum = new DatagramSocket(portNumber);
        gson = new Gson();

        this.UTS = new ArrayList<Double[][]>(Arrays.asList(
                new Double[][] { { 0.0, 0.0 }, { 0.0 } },
                new Double[][] { { 0.0, 1.0 }, { 0.0 } },
                new Double[][] { { 1.0, 0.0 }, { 0.0 } },
                new Double[][] { { 1.0, 1.0 }, { 0.0 } }));

        this.neuralNetwork = new NeuralNetwork(2, 5, 1, null, null, null, null, this.UTS);
    }

    private String knownValues(JsonObject reqObj) {

        double val1 = reqObj.get("val1").getAsDouble();
        double val2 = reqObj.get("val2").getAsDouble();
        double val3 = reqObj.get("val3").getAsDouble();
        double val4 = reqObj.get("val4").getAsDouble();

        ArrayList<Double[][]> newTrainingSets = new ArrayList<>();
        newTrainingSets.add(new Double[][]{{0.0, 0.0}, {val1}});
        newTrainingSets.add(new Double[][]{{0.0, 1.0}, {val2}});
        newTrainingSets.add(new Double[][]{{1.0, 0.0}, {val3}});
        newTrainingSets.add(new Double[][]{{1.0, 1.0}, {val4}});

        neuralNetwork = new NeuralNetwork(2, 5, 1, null, null, null, null, newTrainingSets);

        Double[][][] trainingSetsArray = neuralNetwork.getCurrentTrainingSets().toArray(new Double[neuralNetwork.getCurrentTrainingSets().size()][][]);

        JsonObject resObj = new JsonObject();
        resObj.addProperty("response", "setCurrentRange");
        resObj.addProperty("status", "OK");
        System.out.println(resObj);
        return gson.toJson(resObj);
    }

    private String values() {
        // Fetches the current training set configurations


        JsonObject resObj = new JsonObject();
        ArrayList<Double[][]> currentTrainingSets = neuralNetwork.getCurrentTrainingSets();
        double[] rangeValues = new double[currentTrainingSets.size()];
        for (int i = 0; i < currentTrainingSets.size(); i++) {
            rangeValues[i] = currentTrainingSets.get(i)[1][0];
        }
        resObj.addProperty("response", "getCurrentRange");
        resObj.addProperty("status", "OK");
        resObj.addProperty("val1", rangeValues[0]);
        resObj.addProperty("val2", rangeValues[1]);
        resObj.addProperty("val3", rangeValues[2]);
        resObj.addProperty("val4", rangeValues[3]);
        System.out.println(resObj);
        return gson.toJson(resObj);
    }

    /* Primary Server Loop:
     * Listens for incoming UDP packets, decodes JSON requests, processes them accordingly,
     * and dispatches responses back to the client.
     */

    public void Programbegin() {
        System.out.println("Server port " + portNumber);
        byte[] dataBuffer= new byte[1024];

        while (true) {
            DatagramPacket newpacket = new DatagramPacket(dataBuffer, dataBuffer.length);
            try {
                sNum.receive(newpacket);
                String jsonReq = new String(newpacket.getData(), 0, newpacket.getLength());
                System.out.println(jsonReq);

                JsonObject reqObj = JsonParser.parseString(jsonReq).getAsJsonObject();
                String res = clientRequest(reqObj);

                byte[] sendData = res.getBytes();

                DatagramPacket sendClientPacket = new DatagramPacket(sendData, sendData.length, newpacket.getAddress(), newpacket.getPort());
                sNum.send(sendClientPacket);
            } catch (Exception e) {
                e.printStackTrace();
                break;
            }
        }
    }

    int mychoice;

    private String runDataset(JsonObject reqObj) {
        // Initiates a training session based on provided iterations


        int iter = reqObj.get("iterations").getAsInt();
        Random rand = new Random();
        ArrayList<Double[][]> currentTrainingSets = neuralNetwork.getCurrentTrainingSets();
        for (int i = 0; i < iter; i++) {
            mychoice = rand.nextInt(4);
            List<Double> inputData = Arrays.asList(currentTrainingSets.get(mychoice)[0]);
            List<Double> outputData = Arrays.asList(currentTrainingSets.get(mychoice)[1]);
            neuralNetwork.trainandtest(inputData, outputData);
        }
        Double Erroring = neuralNetwork.outputError(currentTrainingSets);

        JsonObject object1 = new JsonObject();
        object1.addProperty("response", "train");
        object1.addProperty("status", "OK");
        object1.addProperty("val1", Erroring);
        System.out.println(object1);
        return gson.toJson(object1);
    }
    private String randomData(JsonObject Obj2) {
        // Tests the neural network with specified inputs and returns the prediction

        double ip1 = Obj2.get("val1").getAsDouble();
        double ip2 = Obj2.get("val2").getAsDouble();
        List<Double> inputs = Arrays.asList(ip1, ip2);
        List<Double> predOutput = neuralNetwork.feedForward(inputs);
        JsonObject resObj = new JsonObject();
        resObj.addProperty("response", "test");
        resObj.addProperty("status", "OK");
        resObj.addProperty("val1", predOutput.get(0));
        System.out.println(resObj);
        return gson.toJson(resObj);
    }


    private String clientRequest(JsonObject Obj3) {

        // Request routing logic

        String reqType = Obj3.get("request").getAsString();

        switch (reqType) {
            case "getCurrentRange":
                return values();
            case "setCurrentRange":
                return knownValues(Obj3);
            case "train":
                return runDataset(Obj3);
            case "test":
                return randomData(Obj3);
            default:
                JsonObject resObj = new JsonObject();
                resObj.addProperty("status", "ERROR");
                resObj.addProperty("message", "Invalid request");
                return gson.toJson(resObj);
        }
    }

}


/* Neural Network Architecture Components:
 * Defines the structure and behavior of neurons and neuron layers, including
 * weight initialization, feedforward logic, and error calculation for backpropagation.
 */
class mainNeuron {
    private double newb1;
    private int Neurons;

    public List<Neuron> neurons;

    public mainNeuron(int numNeurons, Double bias) {
        if(bias == null) {

            this.newb1 = new Random().nextDouble();
        }
        else {
            this.newb1 = bias;
        }
        this.Neurons = numNeurons;
        this.neurons  = new ArrayList<Neuron>();
        for(int i = 0; i < numNeurons; i++) {
            this.neurons.add(new Neuron(this.newb1));
        }
    }
    // Display the neuron layer by displaying each neuron.
    public String convertFunction() {
        String s = "";
        s = s + "Neurons: " + neurons.size() + "\n";
        for(int n = 0; n < neurons.size(); n++) {
            s = s + "Neuron " + n + "\n";
            for (int w = 0; w < neurons.get(n).newweights.size(); w++) {
                s = s + "\tWeight: " + neurons.get(n).newweights.get(w) + "\n";
            }
            s = s + "\tBias " + newb1 + "\n";
        }

        return s;
    }


    List<Double> feedForward(List<Double> inputs) {

        List<Double> outputs = new ArrayList<Double>();

        for(Neuron neuron : neurons ) {

            outputs.add(neuron.outputFunction(inputs));
        }

        return outputs;
    }

    List<Double> getOutputs() {
        List<Double> outputs = new ArrayList<Double>();
        for(Neuron neuron : neurons ) {
            outputs.add(neuron.output);
        }
        return outputs;
    }
}


// Single neuron operations, including activation and error gradient calculations

class Neuron {
    private double bias;
    public List<Double> newweights;
    public List<Double> inputs;
    double output;
    public Neuron(double bias) {
        this.bias = bias;
        newweights = new ArrayList<Double>();
    }

    public double outputFunction(List<Double> inputs) {

        this.inputs = inputs;

        output = newn2(mainOutputCalculation());
        return output;
    }

    public double mainOutputCalculation() {

        double total = 0.0;
        for (int i = 0; i < inputs.size(); i++) {
            total += inputs.get(i) * newweights.get(i);
        }
        return total + bias;
    }


    public double newn2(double totalNetInput) {
        double v = 1.0 / (1.0 + Math.exp(-1.0 * totalNetInput));
        return v;
    }

    public Double Output(double targetOutput) {
        return ErrorOutputCalculation(targetOutput) * InputCalc();
    }

    public Double calculate_error(Double targetOutput) {
        double theError = 0.5 * Math.pow(targetOutput - output, 2.0);
        return theError;
    }

    public Double ErrorOutputCalculation(double targetOutput) {
        return (-1) * ( targetOutput - output);
    }

    public Double  InputCalc() {
        return output * ( 1.0 - output);

    }

    public Double totalWeight(int index) {
        return inputs.get(index);
    }
}


// High-level neural network setup, training, and error calculation

class NeuralNetwork {

    private double LEARNING_RATE = 0.5;

    private int Inputnumbers;


    private mainNeuron hiddenLayer;
    private mainNeuron op1;

    public  ArrayList<Double[][]>  userTrainingSets;

    public ArrayList<Double[][]> getCurrentTrainingSets(){
        return this.userTrainingSets;
    }


    public NeuralNetwork(int numInputs, int numHidden, int numOutputs, List<Double> hiddenLayerWeights, Double hiddenLayerBias,
                         List<Double> outputLayerWeights, Double outputLayerBias, ArrayList<Double[][]> trainingSets) {
        // How many inputs to this neural network
        this.Inputnumbers = numInputs;


        hiddenLayer = new mainNeuron(numHidden, hiddenLayerBias);
        op1 = new mainNeuron(numOutputs, outputLayerBias);

        InputHidden(hiddenLayerWeights);

        HiddenLayer(outputLayerWeights);

        this.userTrainingSets = trainingSets;
    }

    public void InputHidden(List<Double> hiddenLayerWeights) {

        int weightNum = 0;
        for (int h = 0; h < hiddenLayer.neurons.size(); h++) {
            for (int i = 0; i < Inputnumbers; i++) {
                if (hiddenLayerWeights == null) {
                    hiddenLayer.neurons.get(h).newweights.add((new Random()).nextDouble());
                } else {
                    hiddenLayer.neurons.get(h).newweights.add(hiddenLayerWeights.get(weightNum));
                }
                weightNum = weightNum + 1;
            }
        }
    }

    public void HiddenLayer(List<Double> outputLayerWeights) {
        int weightNum = 0;
        for (int o = 0; o < op1.neurons.size(); o++) {
            for (int h = 0; h < hiddenLayer.neurons.size(); h++) {
                if (outputLayerWeights == null) {
                    op1.neurons.get(o).newweights.add((new Random()).nextDouble());
                } else {
                    op1.neurons.get(o).newweights.add(outputLayerWeights.get(weightNum));
                }
                weightNum = weightNum + 1;
            }
        }
    }

    public String toString() {
        String s = "";
        s = s + "-----\n";
        s = s + "* Inputs: " + Inputnumbers + "\n";
        s = s + "-----\n";

        s = s + "Hidden Layer\n";
        s = s + hiddenLayer.toString();
        s = s + "----";
        s = s + "* Output layer\n";
        s = s + op1.toString();
        s = s + "-----";
        return s;
    }


    public List<Double> feedForward(List<Double> inputs) {

        List<Double> hiddenLayerOutputs = hiddenLayer.feedForward(inputs);
        return op1.feedForward(hiddenLayerOutputs);
    }


    public void trainandtest(List<Double> trainingInputs, List<Double> trainingOutputs) {

        feedForward(trainingInputs);
        // Perform backpropagation
        List<Double> pdErrorsWRTOutputNeuronTotalNetInput =
                new ArrayList<Double>(Collections.nCopies(op1.neurons.size(), 0.0));
        for (int o = 0; o < op1.neurons.size(); o++) {
            pdErrorsWRTOutputNeuronTotalNetInput.set(o, op1.neurons.get(o).Output(trainingOutputs.get(o)));
        }
        List<Double> pdErrorsWRTHiddenNeuronTotalNetInput =
                new ArrayList<Double>(Collections.nCopies(hiddenLayer.neurons.size(), 0.0));
        for (int h = 0; h < hiddenLayer.neurons.size(); h++) {
            double dErrorWRTHiddenNeuronOutput = 0;
            for (int o = 0; o < op1.neurons.size(); o++) {
                dErrorWRTHiddenNeuronOutput +=
                        pdErrorsWRTOutputNeuronTotalNetInput.get(o) * op1.neurons.get(o).newweights.get(h);
                pdErrorsWRTHiddenNeuronTotalNetInput.set(h, dErrorWRTHiddenNeuronOutput *
                        hiddenLayer.neurons.get(h).InputCalc());
            }
        }
        for (int o = 0; o < op1.neurons.size(); o++) {
            for (int wHo = 0; wHo < op1.neurons.get(o).newweights.size(); wHo++) {
                double pdErrorWRTWeight =
                        pdErrorsWRTOutputNeuronTotalNetInput.get(o) *
                                op1.neurons.get(o).totalWeight(wHo);
                op1.neurons.get(o).newweights.set(wHo, op1.neurons.get(o).newweights.get(wHo) - LEARNING_RATE * pdErrorWRTWeight);
            }
        }
        for (int h = 0; h < hiddenLayer.neurons.size(); h++) {
            for (int wIh = 0; wIh < hiddenLayer.neurons.get(h).newweights.size(); wIh++) {
                double pdErrorWRTWeight =
                        pdErrorsWRTHiddenNeuronTotalNetInput.get(h) *
                                hiddenLayer.neurons.get(h).totalWeight(wIh);
                hiddenLayer.neurons.get(h).newweights.set(wIh, hiddenLayer.neurons.get(h).newweights.get(wIh) - LEARNING_RATE * pdErrorWRTWeight);
            }
        }
    }

    public double outputError(ArrayList<Double[][]> trainingSets) {

        double totalError = 0.0;

        for (int t = 0; t < trainingSets.size(); t++) {
            List<Double> outputrange = Arrays.asList(trainingSets.get(t)[0]);
            List<Double> trainingOutputs = Arrays.asList(trainingSets.get(t)[1]);
            feedForward(outputrange);
            for (int o = 0; o < trainingOutputs.size(); o++) {
                totalError += op1.neurons.get(o).calculate_error(trainingOutputs.get(o));
            }
        }
        return totalError;
    }

}