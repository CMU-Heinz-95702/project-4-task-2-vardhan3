package ds.edu.footballdataapp;

//public class Player {
//    private String name;
//    private int goals;
//
//    public Player(String name, int goals) {
//        this.name = name;
//        this.goals = goals;
//    }
//
//    public String getName() {
//        return name;
//    }
//
//    public int getGoals() {
//        return goals;
//    }
//}

public class Player {
    private String Player; // Should match the JSON key
    private int Goals; // Should match the JSON key

    public Player(String Player, int Goals) {
        this.Player = Player;
        this.Goals = Goals;
    }

    public String getPlayer() {
        return Player;
    }

    public int getGoals() {
        return Goals;
    }
}

